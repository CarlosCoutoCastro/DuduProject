package com.example;
import java.util.List;
import java.util.Arrays;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.Statement;

import com.example.DAO.ObjetoDAO;
import com.example.DAO.BaseDao;

import com.example.model.entity.Objeto;
import com.example.model.entity.Livro;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        ObjetoDAO conexaoObjeto = new ObjetoDAO();
        try {
            conexaoObjeto.getConnection();
            System.out.println("Conexão com sucesso");
            Objeto obj = new Objeto(21,300,20);
     
            Date test = new Date(2010, 20, 30);
            System.out.println(test);

            Livro liv = new Livro(1, 22, 10 ,  "Livro", "Romance", test, "Joao", 300);

            System.out.println(liv.getValorAluguel());
            /* 
            List<Objeto> objetos = conexaoObjeto.listar();

            for(Objeto objeto : objetos){
                System.out.println("-----------------------------------" + 
                                 "\nItem id: " + objeto.getId() + 
                                 "\nQuantidade de Exemplares: " + objeto.getQuantidadeExemplares() + 
                                 "\nValor do aluguel: " + objeto.getValorAluguel());
            }*/
            
            System.out.println("Inserido com sucesso");
        } catch (Exception e) {
            System.out.println("Falha na Conexão");
        }
        

    
    }

 /*
        try{
            Connection conexao = DriverManager.getConnection("jdbc:postgresql://localhost:5432/jdbc_test", "postgres", "1234");
            if(conexao != null){
                System.out.print("Banco de dados conectado com sucesso");
                Statement stm = conexao.createStatement();
                insereDados(stm);
                consultadados(stm);
                conexao.close();
            }else{
                System.out.println("Erro na conexao");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        
    public static void consultadados(Statement stm){
        String sql = "select id,nome from usuario";
        try {
            ResultSet result = stm.executeQuery(sql);
            while(result.next()){
                System.out.println("id: "+ result.getInt("id") + " Nome: " + result.getString("nome"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void insereDados(Statement stm){
        String sql = "insert into usuario (id, nome) values (5, 'Joao')";
        try {
            stm.executeUpdate(sql);
        } catch (Exception e) {
            
        }
    }
     */
}
