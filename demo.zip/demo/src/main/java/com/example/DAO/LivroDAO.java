package com.example.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.model.entity.Livro;



public class LivroDAO extends BaseDaoImpl<Livro>{

	
	public Long inserir(Livro liv) {
		Connection con = getConnection();
		String sql = "INSERT INTO tb_livros (nome,email,senha,id_endereco) "
				+ "values (?,?,?,?)";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, liv.getNome());
			ps.setString(2, liv.getEmail());
			ps.setString(3, liv.getSenha());
			ps.setLong(4,liv.getEndereco().getId());
			ps.execute();
			ps.close();
			
			sql = "SELECT * FROM tb_users as e WHERE e.email=?";
			ps = con.prepareStatement(sql);
			ps.setString(1, liv.getEmail());
			ResultSet rs = ps.executeQuery();
			if(rs.next()) return rs.getLong("id");
			else return null;
					
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		finally {closeConnection();}
		
	}

	@Override
	public void deletar(Livro liv) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void alterar(Livro liv) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Livro buscar(Livro liv) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Livro> listar() {
		Connection con = getConnection();
		String patric = "SELECT * FROM tb_users";
		List<Livro> Livros = new ArrayList<Livro>();
		try {
			PreparedStatement ps = con.prepareStatement(patric);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Livro liv = new Livro();
				
				try {
					liv.setNome(rs.getString("nome"));
					liv.setEmail(rs.getString("email"));
					liv.setSenha(rs.getString("senha"));
					liv.setId(rs.getLong("id"));
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Livros.add(liv);				
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {closeConnection();}
		return Livros;
	}

}
